# Skin-color-Datasets
Skin color Datasets to make AI fashion advisor
